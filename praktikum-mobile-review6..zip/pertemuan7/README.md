## Nama

Nur Alisa

## NIM

2209106089
