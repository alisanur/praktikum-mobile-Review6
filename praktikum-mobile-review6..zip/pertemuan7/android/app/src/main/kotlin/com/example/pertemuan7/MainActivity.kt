package com.example.pertemuan7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
